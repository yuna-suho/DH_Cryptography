with open('encfile', 'r', encoding='utf-8') as f:
    enc_txt = f.read()

hex_list = [(hex(i)[2:].zfill(2).upper()) for i in range(256)]
enc_pairs = [enc_txt[i:i+2] for i in range(0, len(enc_txt), 2)]
dec_list = list(range(len(enc_pairs)))

for i in range(len(enc_pairs)):
    hex_b = enc_pairs[i]
    idx = hex_list.index(hex_b)
    dec_list[i] =  hex_list[idx - 128]

dec_ = bytes([int(b, 16) for b in dec_list])

with open('decrypted_flag.png', 'wb') as f:
    f.write(dec_)