import re
from string import ascii_lowercase, ascii_uppercase, digits

words = ascii_uppercase + ascii_lowercase + digits
class Vigenere:
    def __init__(self, key):
        self._key = key

    def shift(self, a, d):
        if a not in words:
            return a
        index = words.index(a)
        return words[(index + d) % len(words)]

    def encrypt(self, pt):
        ct = ""
        for i in range(len(pt)):
            ct += self.shift(pt[i], self._key[i % len(self._key)])
        return ct

    def decrypt(self, ct):
        pt = ""
        for i in range(len(ct)):
            pt += self.shift(ct[i], -self._key[i % len(self._key)])
        return pt



def main():
    key = [47, 22, 41, 1, 29, 2, 53, 53, 35, 20, 47, 60, 20, 20, 48, 5]
    with open('output.txt', 'r', encoding='utf8') as f:
        secret_enc = f.read()[len('my encrypted sentence > '):]
    cipher = Vigenere(key)
    plaintext = cipher.decrypt(secret_enc)
    print(re.search(r'DH\{[^>]*\}', plaintext).group(0))

if __name__ == '__main__':
    main()