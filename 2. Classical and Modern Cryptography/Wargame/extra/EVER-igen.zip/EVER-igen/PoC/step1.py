from string import ascii_lowercase, ascii_uppercase, digits


words = ascii_uppercase + ascii_lowercase + digits

with open('output.txt', 'r', encoding='utf8') as f:
    secret_enc = f.read()[len('my encrypted sentence > '):]

key = ['x' for _ in range(16)]

# for i in range(0, len(secret_enc), 16):
#     print(secret_enc[i:i+16])
 
# ...
# R. Ek{sreSsZxMq8
# OPf37BwUdvpZKzQ8
# oNg7Z8rwASqbxQsB
# l0g935rwDLQaNxNC
# nxK44g}

# DH{...} => Ek{...}

# print(secret_enc.find('Ek{') % 16)
key[secret_enc.find('Ek{') % 16] = words.index('E') - words.index('D')
key[secret_enc.find('Ek{') % 16 + 1] = words.index('k') - words.index('H')

print(key)

# key = ['x', 'x', 'x', 1, 29, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x']