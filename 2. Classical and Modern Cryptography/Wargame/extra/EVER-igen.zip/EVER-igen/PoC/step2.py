from string import ascii_lowercase, ascii_uppercase, digits, punctuation

words = ascii_uppercase + ascii_lowercase + digits

with open('output.txt', 'r', encoding='utf8') as f:
    secret_enc = f.read()[len('my encrypted sentence > '):]

enc_words = [i for i in secret_enc.split(" ")]

def find_special(word):
    for c in word:
        if c in punctuation:
            return True
    return False

for w in enc_words:
    # target = "Vigenere"
    target = "cipher"
    if len(w) == len(target):
        # print(w)
        if not find_special(w):
            key = ['x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x']
            pos = secret_enc.find(w)
            for i in range(len(target)):
                key[(pos + i) % 16] = (words.index(w[i]) - words.index(target[i])) % 62
            print(key)

# DH
# ['x', 'x', 'x', 1, 29, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x']

# Vigenere
# ['x', 'x', 41, 1, 29, 2, 53, 53, 35, 20, 'x', 'x', 'x', 'x', 'x', 'x']
# [4, 31, 43, 3, 24, 11, 36, 60, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x']
# [47, 22, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 47, 60, 20, 20, 48, 5]
# [61, 24, 37, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 40, 12, 33, 1, 0]
# ['x', 'x', 'x', 'x', 'x', 'x', 33, 45, 48, 35, 42, 12, 22, 16, 'x', 'x']

# cipher
# ['x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 8, 23, 32, 61, 34, 7, 'x', 'x']
# [47, 22, 41, 1, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 48, 5]
# ['x', 'x', 'x', 'x', 'x', 2, 45, 49, 39, 20, 33, 'x', 'x', 'x', 'x', 'x']
# ['x', 'x', 'x', 'x', 'x', 'x', 'x', 53, 35, 20, 47, 60, 20, 'x', 'x', 'x']
# ['x', 'x', 'x', 'x', 'x', 1, 49, 43, 42, 33, 34, 'x', 'x', 'x', 'x', 'x']
# ['x', 'x', 41, 1, 29, 2, 53, 53, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x']
# ['x', 'x', 'x', 'x', 7, 2, 52, 5, 31, 16, 'x', 'x', 'x', 'x', 'x', 'x']
# [47, 21, 55, 59, 25, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 45]
# ['x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 2, 52, 6, 33, 55, 50]
# ['x', 'x', 'x', 'x', 45, 16, 46, 3, 33, 10, 'x', 'x', 'x', 'x', 'x', 'x']
# [47, 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 'x', 60, 20, 20, 48, 5]

# key = [47, 22, 41, 1, 29, 2, 53, 53, 35, 20, 47, 60, 20, 20, 48, 5]
